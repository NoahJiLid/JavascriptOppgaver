// console.log(2*2);
// console.log(2+2);
// console.log(8/2);
// console.log(8-4);

// let myName = "Noah"
// let mySurName = "Ji"
// console.log(myName + " "+ mySurName)

// let tall1 = 67
// let tall2 = 67
// if (tall1 > tall2) {
//     console.log(`${tall1} er større enn ${tall2}`);
// } else if (tall1 < tall2) {
//     console.log(`${tall1} er mindre enn ${tall2}`);
// }else {
//     console.log(`${tall1} er lik ${tall2}`);
// }
// if (tall1 == 6 && tall2 == 7) {
//     console.log("67");
// }

// Spørsmål 1
let tekst1 = "Six"
let tekst2 = "Seven"
let kombinertTekst = tekst1 + " " + tekst2;
console.log(kombinertTekst);

// Spørsmål 2
let tall1 = 10;
let tall2 = 5;
let tall3 = 2;
let sum = tall1 + tall2 + tall3;
console.log(sum);

// Spørsmål 3
let tallA = 10;
let tallB = 5;
let tallC = 2;
let produkt = tallA * tallB * tallC;
console.log(produkt);

// Spørsmål 4
if (tall > 0) {
    console.log("positivt");
} else if (tall < 0) {
    console.log("negativt");
} else {
    console.log("null");
}

// Spørsmål 5
if (tall1 > tall2) {
    console.log(`${tall1} er større enn ${tall2}`);
} else if (tall1 < tall2) {
    console.log(`${tall1} er mindre enn ${tall2}`);
} else {
    console.log(`${tall1} er lik ${tall2}`);
}

// Spørsmål 6
if (tall1 > tall2 && tall1 > tall3) {
    console.log(`${tall1} er det største tallet`);
} else if (tall2 > tall1 && tall2 > tall3) {
    console.log(`${tall2} er det største tallet`);
} else {
    console.log(`${tall3} er det største tallet`);
}

// Spørsmål 7
if (tall > 49) {
    console.log("Bestått");
} else if (tall <= 49){
    console.log("Ikke betsått");
} else {
    console.log("Ugyldig poengsum");
}

// Spørsmål 8
if (tall === 1) {
    console.log("Mandag");
} else if (tall === 2) {
    console.log("Tirsdag");
} else if (tall === 3) {
    console.log("Onsdag");
} else if (tall === 4) {
    console.log("Torsdag");
} else if (tall === 5) {
    console.log("Fredag");
} else if (tall === 6) {
    console.log("Lørdag");
} else if (tall === 7) {
    console.log("Søndag");
} else {
    console.log("Hvilken dag er det i dag? Hvilken dag er det i dag? Er det Valorant(JAAA)))");
}

// Spørsmål 9
let celsius = 25;
let fahrenheit = (celsius * 9/5) + 32;
console.log (`${celsius} Celsius er ${fahrenheit} Fahrenheit`);

// Spørsmål 10